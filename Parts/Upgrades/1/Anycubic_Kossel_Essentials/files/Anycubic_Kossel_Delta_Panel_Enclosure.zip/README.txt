                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2838583
Anycubic Kossel Delta Panel Enclosure by ArtieH is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

From day one of owning the Anycubic Kossel Linear Plus Delta printer, I was annoyed by the design of the open control panel. It not only makes the printer look unfinished, it puts the electronics at risk from impact, strain or short circuits. Lastly, I also did not like fumbling for the SD card slot. After several iterations of the design (11 to be exact) I have designed an enclosure that I am aesthetically and mechanically happy with. I hope you find it to be also.
<br />
**I have added a split design to the files which includes a left and right side and an H-clip to connect them. These new files will allow printing on beds smaller than the Plus's 230mm build plate.**

# Print Settings

Printer: Anycubic Kossel Linear Delta Plus
Rafts: No
Supports: No
Resolution: .2mm
Infill: 20%

# Post-Printing

## Installation

The panel is designed to use the existing hardware to attach it to the rails using the top holes. If you want to also attach the panel with the bottom holes you will need two M4*6 screws and two T-nuts.
<br />
If you printed the split version use the H-clip to assemble the two halves. The bottom of the clip is elongated on one end. This is the end that will be toward the rear of the enclosure. (toward the printer, see image)

# How I Designed This

Design worked out in CadStd Pro then exported sketches to InkScape for some cleanup (CadStd doesn't play well with 123D Design) then export to 123D Design. The majority of the design was then fine tuned in 123D Design.

![Alt text](https://cdn.thingiverse.com/assets/4f/06/f0/77/17/Kossel_Panel_Enclosure.png)