                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2458749
Spool Holder for 2020 Aluminum by kmccon is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Inspired by Kals spool holder, here is a version that can be hung off of 2020 Aluminum extrusions.

The rollers 625ZZ bearings.  They are a tight fit so you will need to press the bearings in.

There are two versions included.  Version 1 uses M5X16 screws. Version 2 uses M3X16 screws and M3 flat washers.

Installation on the extrusion is very simple.  Hook the lower edge of the frame into the lower opening in the extrusion and then pivot into position (See pictures)  Once installed they holders can be slid along the extrusion to fit your spool.

Install the spool by placing one rim in the rollers and then sliding the other frame to match the other spool rim.  Rotate the spool to make sure everything moves smoothly.

Revised:  Updated 5 mm sides - Opened 5 mm hole slightly to make installation easier.  Added a 5.25 mm countersunk section to help screw start straight.