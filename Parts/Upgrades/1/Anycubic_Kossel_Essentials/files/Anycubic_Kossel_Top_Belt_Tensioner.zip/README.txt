                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2827665
Anycubic Kossel Top Belt Tensioner by Atziano is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This thing is an top mounted belt tensioner which allows you to adjust the tightness of the timing belts with screws.
It is possible to lift up the top belt wheel for about 7mm. 
If you put the timing belt already a bit taut during assembly, you will never need the full 7mm.
In my case, I only needed about 2mm.
In addition, these also serve as covers for the upper pulleys.
The belt tensioners is made out of two parts: the housing and the slider.
For all three belts of the Kossel, you need these two parts three times.
Also the belt have to be replaced because the position of the upper belt weel is about 15mm higher mounted. So the orginal belt is too short...unless you have left something extra length on the original timing belt.

For the assembly you need (for all three sides):

- 3 longer timing belts (about 40mm longer than the orginal one)
- 12 pieces of screws M4x8mm 
- 12 pieces of T-nuts M4
- 9 pieces of screws M3x20mm
- 15 pieces of M3 nuts

There are two vesions of the covers to download:

V1.0 this version is without logos, signs and text.
V1.1 this version is with countersunk adjusting screws, direction arrows, +/- signs, deltalogo and min/max scale.

These two versions work exactly the same, the differences are only visual.

Please do not stretch the belt too much, a little more than with the original springs, that's enough.
To straighten all three belts the same way, i listen with my ear to the tensioners and peck at the belts like a guitar until the tone is equal.

# Print Settings

Printer: Anycubic Kossel Linear Plus
Rafts: Doesn't Matter
Supports: Yes
Resolution: 0,2mm
Infill: min 20%

Notes: 
Supports only are needed for the covers V1.0 and V1.1.
The Slider can be printed without.