                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2574417
Effector Anycubic / compacto sin casquillos / compact without copper spacers by rxdroid is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Effector Anycubic compacto sin casquillos
Effector Anycubic compact without copper spacers

Es una evolución del original, https://www.thingiverse.com/thing:2572879 para eliminar los casquillos de latón y reducir la distancia ente centro de las rótulas para obtener más estabilidad, la distancia entre varillas es de 52mm

It is an evolution of the original, https://www.thingiverse.com/thing:2572879 to remove the copper spacers and reduce the distance between center of the ball joints for more stability, the distance between rods is of 52mm

# Print Settings

Printer: Anycubic Lineal Plus
Rafts: Doesn't Matter
Supports: No
Resolution: 0.2
Infill: 20%

Notes: 
Printed in PETG

# Post-Printing

Hacen falta 6 tornillos M3 x 15mm
6 M3 x 15mm screws are required