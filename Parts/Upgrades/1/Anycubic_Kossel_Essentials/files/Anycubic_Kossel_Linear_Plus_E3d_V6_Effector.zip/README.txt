                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2422030
Anycubic Kossel Linear Plus E3d V6 Effector by grantp69 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a simple duplicate of the standard metal effector from the Anycubic Kossel Linear Plus. All sizes and dimensions are the same. It will mount an E3d V6 hot end, the one in the picture is a clone. You can then make your choice of fan duct. Any fan duct designed to clip onto the Hotend fins should work. This is the one in the picture. 

https://www.thingiverse.com/thing:1373201

It works well and fits well, no screw needed.

It reduces the available build height by about 30mm but I felt that was worth it so I could add better part cooling.

Clamps use m3 screws 4 off, Print 2 of those.

Arms fit the effector using the same mounting screws.

If you do use the same fan duct insulate the hot end from the close proximity of the heat block.


# Print Settings

Printer Brand: Prusa
Printer: Prusa Clone
Rafts: No
Supports: No
Resolution: 0.2
Infill: 30%