                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2831633
Anycubic Kossel Linear Plus Hardened Bed Corner by kubik256 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

NOT TESTED/PRINTED RIGHT NOW !!!! PRINT IT ONLY AT YOUR OWN RISK!
=====================
I WILL ADD RESULT PHOTOS AFTER FIRST PRINT...
=====================
Idea is to create corner cover together with heated bed holder and corner support (make delta skeleton more stiff) in one piece - 3 in 1 :)

Modified: 2018-04-06 . repaired corner size, added bed holder.
 
STILL WORK IN PROGRESS... IF YOU HAVE TIME AND SKILLS YOU CAN TRY TO FINISH THIS I'M VERY BUSSY. 3MF FILE IS WORKING FILE WITH ALL PARTS NOT MERGED TOGETHER ;)
=====================
All credits goes to original makers Maketo and Johnnyboyye. Thanks ;)
---------------------