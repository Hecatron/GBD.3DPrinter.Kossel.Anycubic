                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2671635
Part Cooling Nozzle for Anycubic Kossel by GER776 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

UPDATE 2018-01-11: Added _RevA. Came across the problem that the hotend had difficulties reaching and keeping very high temperatures as the original nozzle seems to cool the hotend as well. Probably related to the comment by friggy?
Changed the nozzle to blow more downward and also increased clearance to the hotend to make for an easier fit.
_____________________
Part cooling nozzle for stock radial fan on Anycubic Kossel. I have the Linear Plus version, but assume all use the same effector, so should fit all Anycubic Kossels.

It is a bit of a monstrosity compared to the other very elegant cooling nozzle designs out there, but this was done in order to increase the cross sections for air flow. This way we get the most out of the stock radial fan.

The nozzle really helps a lot when printing PLA at high temperatures for best layer adhesion.

# Print Settings

Printer: Anycubic Kossel Plus
Rafts: No
Supports: No
Resolution: 0.2
Infill: 20%

Notes: 
Print in ABS for heat resistance. The slopes will print just fine, turn off supports.