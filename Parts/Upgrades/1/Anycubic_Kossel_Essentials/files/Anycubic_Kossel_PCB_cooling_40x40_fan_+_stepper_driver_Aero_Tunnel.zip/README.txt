                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1949625
Anycubic Kossel PCB cooling 40x40 fan + stepper driver Aero Tunnel by Facocero is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

If you have installed a heated bed on your printer and you think that the control board needs cooling, use this thing.

"It works perfectly for cooling your new TMC2100"

update: 

- now is available to install the "Aero Tunnel" for cooling your stepper driver without interfering with the heating of your heated bed.
- The update consists of an add-on, it does not involve any change to the previously  installed PCB support.

**************************************************************************************
I used this fan configuration for my Controller Board:

Extruder cooler: FAN1 connector
PCB cooler: FAN2 connector

Setting up two simple changes this firmware https://drive.google.com/open?id=0B8VIB533cgdMdVl2Z2tHWkJHbTA in "Configuration_Adv.h"

1: #define E0_AUTO_FAN_PIN -1 -----> edit to #define value E0_AUTO_FAN_PIN 7

2:  #define CONTROLLERFAN_PIN -1 -----> edit to #define CONTROLLERFAN_PIN 44

For peace of our ears, the PCB cooling fan will be started only when printing, but will be turned off to finish printing. ;-)

You can reverse the pin 7 to pin 44 at your convenience, it depends of the connector you used for your fans
**************************************************************************************

Update v1.2:

- tunnel with increased height and length for TMC2100 + Protector Filter or with Big heat sink for higher cooling performance


# Print Settings

Rafts: No
Supports: Yes
Resolution: 0.2
Infill: 35