                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2252569
Kossel 3D printer (Anycubic linear delta) bed leveling by ricardodeazambuja is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is my first trial to correct the problem of not having automatic leveling. I tried to make it tough, but still not enough for a very precise leveling. It works, but I was dreaming I would be able to keep the calibration even after removing the bed because I had the extra nuts (the thin ones) to lock it...
Another side effect is the shrunk printing area. With the new adaptors I had to setup Cura with 150mm instead of the original 180mm (but I really don't think this printer would be capable of printing something close to 180mm of diameter).

**Hint:** if your printer is not very precise, scale up the nuts inside Cura (or Slic3r) before generating the g-code. I suggest scaling only X and Y dimensions by 101% (or scale factor 1.01).

**How to assemble it**
The Nut_counter is the first nut (from bottom to top). If you look at the first photograph, you may see it. It is supposed to lock the big, tough, nut.

Step-by-step:
1) Attach the Base to your printer (you should center it in relation to each triangle vertice).
2) Add the Nut_counter and put it all the way down to free the way.
3) Add the Nut.
4) Add your printer bed.
5) Add the Nut_small_new.
6) Level the bed using the Nut and the Nut_small_new.
7) Use the Nut_counter to lock the Nut.
8) Print the AnycubicTestRing140 to verify if it's working. I also paused the printer to correct the bed level during the very first layers.

Be careful, depending on your setup for brim/skirt, your printer may hit the bed levelers when printing the AnycubicTestRing140 test file. I've changed my Machine settings to a bed with diameter of 150mm to avoid *surprises*.

This bed leveler is not a very good solution because it's quite hard to get the leveling right and if you remove the bed plate you will need to redo it. In the future, I will design something better that allows me to attach an extra removable bed plate or, even better, remove the one I have without ruining the leveling.

Here I'm explaining how I did it:
http://ricardodeazambuja.com/3d_printing/2017/04/16/bed_levelling_blu-tack/


If you liked this thing, don't forget to visit my personal website: [ricardodeazambuja.com](ricardodeazambuja.com)

**DISCLAIMER: use it at your own risk ;)**