                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2789305
Anycubic Kossel Switch and Controlbox by Atziano is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I wanted to monitor the voltage and current of my printer and therefore I made a small box that included a voltmeter and ampere meter and some switches.

The box fits next to the standard display when it is moved to the side.
For mounting the Switchbox on the Printer 4 T-nuts M3 and 4 screws M3x10mm are required.
And for the Frontcover you need 4 M3 Screws 5-10mm lengh.

The display shows the voltage from the power supply and the current consumption of the entire printer. For this purpose, a shunt was installed in the power supply which allows currents up to 50A to be displayed.

The two buttons next to the display are for the LED lighting and to cancel the printing. (Killswich). This is controled by a raspberry pi with the enclosure plugin for octoprint.
With the switch on the site, the mains voltage is switched on and off. This make it easier to switch the printer on and off because the original switch is on the back of the printer ...

Things i have used:

- DROK YB27VA-50A Dual Display Digital Voltmeter/Ammeter, DC 0V-100V/50 Amp, +50 Amp/75mV Shunt 
- 1 round Switch 21mm cutout diameter (on/off)
- 2 Pushbuttons 18mm cutout diameter (normally open)
- Some wires and Crimpconnectors

The .skp files are also to download when someone want to redraw the cutout diameter for the display or the switches.



# Print Settings

Printer: Anycubic Kossel Linear Plus
Rafts: Doesn't Matter
Supports: Yes
Resolution: 0,2
Infill: 20