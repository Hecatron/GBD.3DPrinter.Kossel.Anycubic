                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2281894
Carriages for Anycubic Delta Kossel Linear Plus by theinternal is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

**UPDATE 30.06.17**

Is anybody using any of these right now? Please comment if you do, share your opinion, share your makes! I'm currently working on an effector redesign on and off to make this more complete and get rid of the spacers entirely.

**Original posting:**

If you own an Anycubic Delta Kossel Linear Plus Printer that relies on these ugly workaround "copper spacers" that Anycubic ships to make up for their design mistakes - here's your solution to getting rid of half of them at least. :)

I took the original carriages ("belt tensioners" as Anycubic calls them) and redesigned them in Fusion 360.

**Advantages:**

- Belt clearance improved. (No more friction on the left side of the carriages.)
- Propper width makes "copper spacers" obsolete on the carriage side.
- Improved stability/rigidity.

**Disadvantages:**

- Due to the enhanced belt clearance, there are areas where less pressure might be applied to the GT6 belt as opposed to the original carriages (i.e. on the right side of the carriage). I tried to compensate for this by slightly slanting the surface from bottom to top (the original part does that too). Whether this is sufficient in the long run remains to be seen.

There are three versions: 50, 51 and 52mm wide. Each was designed for **2 M3x20mm screws, 2 M3 nuts (for the rods)+4 M3x8mm screws (linear rail slider)** that originally shipped with the printer. THREE versions??? Well, here's why: Anycubic's "copper spacers" are somewhat too soft and flexible to give an exact spacing in the end. While the original effector's mounting screw distance is about 43mm, depending on the spacers you chose and the amount of force you applied on them during installation, you might end up with all kinds of diagonal rod mount distances at the effector in the end. In my case when using the "copper spacers" at the effector, I get distances of 50.8-51mm. (43mm+2x4.5mm=51mm.) YMMV! Since the rods in a delta have to be as closely parallel as possible, choose the spacing that suits your needs according to your measurements.

[The pictures above are from a pre-release 50mm version I'm using with 0.5mm spacers and custom made Traxxas 5347 ball joint rod ends and 250mm carbon rods for longer, more stable rods (total length 284mm) at the expense of z build height.]

# Print Settings

Printer: Taront3rD
Rafts: No
Supports: Yes
Resolution: 200 micron
Infill: ≥25%

Notes: 
The little arms need supports.