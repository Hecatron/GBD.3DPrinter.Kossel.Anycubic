                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2024677
Kossel Base Stand by peaberry is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Additional base stand for Anycubic Kossel Linear (and possibly for similar Kossel printers with 20mm extrusions) which raises the whole printer by 52mm, to provide clearance for a 50mm tall power supply (or additional space for the electronics).

Update: 01/03/18 - I've added two taller versions with 75mm height and 100mm height, for those who need more clearance for their electronics. Also uploaded a SketchUp file for ease of editing.

There are two 4mm mounting holes to attach it to the printer (with M4x10 screws and nuts), and a rebate with three 3mm holes on two sides designed for side panels up to 4mm thick to be fitted. It also has an opening to allow the end-stop wires to be run down the central hole in the tower extrusions.

There's also a 3.5mm through hole which I tapped with an M4 thread, so that a base panel could be attached with three countersunk M4 screws.

If the machine has 240mm extrusions, the side panels would need to be 240x52mm. There are three 3mm mounting holes either side, so each panel could be mounted with either 2 or 4 screws.

I've included an optional captive nut plate which can be used to hold two M3 nuts, which then allows the side panels to be removed and replaced at any time, without needing to upend the machine and remove the base. To attach this plate, I used a countersunk screw and nut through the central hole, and the two outer holes are then used to mount the panel.

For the side panels, I also made this fan cover:
https://www.thingiverse.com/thing:2039193

cilynx has also designed some printable side panels which can be customised:
https://www.thingiverse.com/thing:2577313

# Print Settings

Printer: Anycubic Kossel Linear
Rafts: No
Supports: No
Resolution: 0.2mm layer height, 0.8mm shell thickness
Infill: 20%