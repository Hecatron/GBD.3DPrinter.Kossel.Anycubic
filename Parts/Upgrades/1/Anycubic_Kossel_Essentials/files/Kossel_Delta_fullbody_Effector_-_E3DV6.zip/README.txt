                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1569106
Kossel/Delta fullbody Effector - E3DV6 by kirill91 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Warning!  This design require particular attention on insulation of Hot End because of proximity between Hot End & Effector Structure. See the dedicated picture of insulation by special cotton and kapton.

Fullbody Effector for Delta Kossel structures:

- 3 x 30mm fan ventilation, same flow on hotend & print.
- Optimized cones for IGUS KBRM03 Rodends.
- Compact frame with minimum necessary taken space.
- 25mm DELTA_EFFECTOR_OFFSET

UPDATE 1.1:

- Optimized air flow on the nozle with dedicated support
- Closed 1 of 3 air flow holes in proximity of always On fan

UPDATE 1.2:

- After many requests, released the source of the project compiled in SolidWorks 2014

Enjoy!