                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2809492
Anycubic Kossel Part Cooler (Optimized) by nurtext is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

__Update__

2018-03-01 v2: Added 50/50 divider for even air distribution

__To do__

- ~~Simplified geometry (remove text and marks for cleaner and faster printing)~~
- Optimize airflow
  - ~~50/50 divider inside fan connector for even air distribution~~
  - Angle optimization for less air turbulences

# Print Settings

Printer: Anycubic i3 Mega
Rafts: No
Supports: No
Resolution: 0.1 or 0.2 mm
Infill: 20 - 30 %

Notes: 
Make sure the print is watertight, you don't want to risk loosing precious air from the small fan.

Use 2 perimeters and at least 4-6 top/bottom layers. The exact amount depends on your actual layer height. I highly recommend using 4 layers when printing with 0.2 mm and 6 when printing with 0.1 mm.

You may use supports on the screw holes depending on how your printer is calibrated.