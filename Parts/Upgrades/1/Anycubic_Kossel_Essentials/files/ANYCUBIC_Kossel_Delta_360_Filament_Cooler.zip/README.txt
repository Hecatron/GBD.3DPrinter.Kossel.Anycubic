                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1978765
ANYCUBIC Kossel Delta 360 Filament Cooler by Facocero is licensed under the Creative Commons - Attribution - No Derivatives license.
http://creativecommons.org/licenses/by-nd/3.0/

# Summary

Cooler fan duct for an efficient cooling to 360°

V2:
- Fixed distance of the screw holes (now fit perfectly in the effector holes);
- Eliminated useless screw holes;


New V3 version:
- Slightly retouched size of the toroid;
- Fixed distance of the screw holes (now fit perfectly in the effector holes);
- Eliminated useless screw holes;
- Added intake duct for the effector;
- Increase quantity of air emitted.

V3.1:
- STL Bug Fix


Are welcome comments and photos of your prints thanks ;-)


# Print Settings

Rafts: No
Supports: Yes
Resolution: 0.2
Infill: 50

Notes: 
Pinting in ABS
Bed: 100°C
Support: Touching buildplate only