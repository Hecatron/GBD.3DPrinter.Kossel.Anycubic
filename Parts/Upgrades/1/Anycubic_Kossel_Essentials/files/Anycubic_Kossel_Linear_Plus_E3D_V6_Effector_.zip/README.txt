                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2640121
Anycubic Kossel Linear Plus E3D V6 Effector  by Old-Steve is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I made the connecting rod mounting points longer so I don't have to use the copper spacers anymore.
They are 52mm wide without spacers.
I added a small round brim under each mounting point to help minimize warping. Trim away post print. 
I added a nut pocket so I can use a 3mm X 20mm bolt with a nut and with the rod end installed, the bolt will just reach the nut. 

I have noticed with repeated assembly and disassembly that the mounting hole for the E3D will start to get a little loose, so I added 3 screw holes pointing in towards the center, to help lock down the E3D.
The top collar does a pretty good job of holding it secure, but it is better with the 3 screws. Just don't over tighten them, snug is enough. 

The top collar - will take (2) 3mm x 15-20mm screws and nuts. 20's will work but 15's look a little better.

I have 2 square holes on each side. You can either pass wires through the holes, or use the holes as anchor points for wire ties, or use my little wire clips.

I made a holder for my bore scope, a tiny camera inside a 10mm diameter housing. 

I made a stand for my effector with the extended rod bearing anchor points. Makes it a little easier to work on. Also doubles as a display stand for your spares. 

I am still working on the carriages. I have them printed but not installed yet. Same thing, no copper spacers. The rod end mounting points are 52mm wide. These were just a very minor remix. I placed the nut pockets on top because, well, gravity sucks. I added a tiny brim and support for accuracy and non warping. Trim away post print.

I re-mixed (again) some carriages that really are belt tensioners too. 
https://www.thingiverse.com/thing:2653647

I printed these in ABS with 50% infill.

effector          2640121
carriages       2653647
fan shroud     2846998
UBL adapter  2847002