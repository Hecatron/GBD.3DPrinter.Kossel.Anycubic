                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2889662
Anycubic Kossel Essentials by Oz_Fisher is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Every single thing you could want or need for the Anycubic kossel includes Linear Plus.

All essential upgrades,mods and replacement parts in one download.

List includes...
Fan ducts(several to choose from or print them all and test each one)
Effectors(there are a few to choose from including stock style,E3DRV5/6 style and Delta style
Frame parts(reinforcements and extrusion covers/fillers)
LCD knob/back cover
LED control box/LED holders for "LED mod"(add RGB LED lights to you're Kossel)
Extruder knob/filament filter/bowden frame support/flex tuning for flexible filaments
Fan cooled feet(found some LED 40x40x10mm fans on ebay,hooked up to a fan controller,works very well to keep the steppers nice and cool and looks cool to boot!)
Bed leveling and bed holders(if you are using a glass bed such as the Ultrabase which I highly recommend using these will hold the bed in place)
Front control box with cover for those who wish to see actual voltage and other power info
Also including a very nice and very cool spool holder,it sits on top and will require some bearings 625ZZ is what it takes but it is held in place by the 20mm frame extrusions so it can slide side to side to load and unload filament,this is by far the easiest to print and lightest weight option I have found
Also Belt tensioners,the ones I included are the easiest to use,very simple design that replaces the very hard to put on spring/clip that comes with the printer and these are adjustable and includes a belt holder so you don't have to use a zip tie to hold the belts together.
Rod dampeners,the 56mm pitch ones included will not break,all the other ones I have used broke after a few prints and would not take abuse no matter what infil I used and all of my parts for my printer I use ABS filament and mostly print at 50% up to 100% for frame oriented parts,still they broke.These included look great and work even better,after 20 prints they are still like new.
PCB cooling duct for 40mm fan,keep those ramps cool,heat sinks are technically enough but for electronics that run all the time or run hot when in use it's best and never a bad thing to have more cooling,the one I included has both the duct and fan base/adapter with both a shallow and deep well for the fan.

All files are the original Zip files with instructions and pictures and also specs to print with,good rule of thumb for newbies is if it is a solid reinforcement part 100% infill is best and the strongest.Also if you are printing something like a part cooling fan duct/effector/bed support/bed leveling I would print it with ABS for the strength and heat resistance.And if using a glass bed and ABS allow the bed to cool to around 60c(you can aim a fan at the base for faster cooling)the part should just slide off the bed with no effort at all.

I hope this helps both newbies and experienced Kossel users alike as I could not find one complete file with ALL the parts you really need for the Kossel Pulley version or Linear plus version.

Lastly I want to say that I did not design any of the including parts,credit should go to those who did.Thank you to all who designed these parts,printing your own upgrade/replacement parts is just as much fun and cool as buying/building the printer.

Feel free to share and please show me you're makes!!

E N J O Y ! ! !