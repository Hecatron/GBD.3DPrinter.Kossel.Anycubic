                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2823816
Anycubic Trigorilla Turbo Fan Board Cooler by enry68 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is my NEW design for Anycubic Trigorilla Mother Board ONLY. This project allows to cool the 5 stepper motor drivers and the Mosfet drivers on the board WITHOUT interfere with the hotbed (only in case of Delta/kossel mount). It can be installed in Anycubic Delta Mini&Plus and in other installations.

The design was made using a TurboFan with output hole of 15x30mm and is locked on the board using the existing holes for screws. Can be printed in PLA, ABS or PETG.


# Print Settings

Printer: Anycubic ie Mega
Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.2mm
Infill: 30%

Notes: 
Print the structure faced down (with the logo ANYCUBIC faced to the bad)