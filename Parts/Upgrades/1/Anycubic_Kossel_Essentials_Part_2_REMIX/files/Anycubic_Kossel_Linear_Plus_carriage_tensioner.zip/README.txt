                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2653647
Anycubic Kossel Linear Plus carriage tensioner by Old-Steve is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Anycubic calls these belt tensioners.
Now I can too.
Be careful not to over tighten the belts.

The connecting rod mounting points are 52mm apart. You do not need the copper spacers.

I removed the original carriages and placed them next to my new adjustable carriages and tried to match the top screw height. It worked! I only had to slightly adjust one of them.
I used 3X20mm screws for the rods, I think the 25's are too long.

I used a 3X20mm screw for the tensioner. This gets me about 10mm of adjustment. That doesn't sound like much, but if you get the belts as tight as you can by hand, then tension them, it is more than enough. I think I have only used 5mm so far. 

I was not too thrilled about my L shaped slider, but I couldn't see another way around that bolt. It works.

I copied and pasted my nut pocket but because of the orientation (I think) the tensioning nut pocket needs to be cleaned out a little bit, post print. The 2 on top are fine. For me anyway. 

These are working well with my E3D V6 effector
https://www.thingiverse.com/thing:2640121
 
I printed these in ABS with 50% infill.

R1 
I made 3 more, 50mm, 51mm, and 52mm wide without the added gusset.
Basically, I trimmed 0.5 from each end of the 51, and 1.0mm from each end of the 50. 
These should work although I have not printed them and tested them. 

effector          2640121
carriages       2653647
fan shroud     2846998
UBL adapter  2847002