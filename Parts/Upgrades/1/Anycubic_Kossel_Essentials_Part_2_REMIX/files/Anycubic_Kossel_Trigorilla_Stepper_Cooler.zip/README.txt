                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2766200
Anycubic Kossel Trigorilla Stepper Cooler by PedaBot is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I will use it with the short one of https://www.thingiverse.com/thing:2747843
And an Noiseblocker XM2 40x40x10mm Fan

The Function of this Part is Great with my TMC2208. DHT11 TI 39°C and the DS18B20 has at same time 36°C. So the out-air-intake was really great and non of the TMC cut off by over heating. Fan Connection see at the picture!!

Only need some m3 screws:
1x 5mm for DHT11
1x 15mm for Fan fixing
2x 40mm for Cover Mount


V1: deleted 
V2: deleted optimized air-input and output
V3: deleted +hole for fan-fixing (M3 screw)
V4: deleted +DHT11 mount (M3 screw)
          "DHT11 Temperatur und relatives Feuchtigkeits-Sensor-Modul für arduino"
V5: add "ANYCUBIC" Logo and optimize output...
V6: add mount for DS18B20 (6mm steel housing)
       and make it a little smaller to be printable on Kossel Plus.

# Print Settings

Printer: Anet A8
Rafts: No
Supports: No
Resolution: 0,15
Infill: 25

Notes: 
Print Speed: 50mm/s
Materials: PETG (Extrudr)
Wall thikness: 1,2
Bottom Thikness: 1,2
Printing Time 5,5h