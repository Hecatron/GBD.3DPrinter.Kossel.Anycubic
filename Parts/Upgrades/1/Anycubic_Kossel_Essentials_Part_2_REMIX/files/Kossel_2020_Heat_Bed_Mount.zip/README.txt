                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2566003
Kossel 2020 Heat Bed Mount by Crashoverride is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Designed for Kossel frame with 240mm horizontal 20x20 aluminium extrusions and 200mm dia. print bed with kapton heater. You will need a piece of ceramic fibre blanket to go underneath the print bed. Ramps mounting bracket included.
There is no hole to run heat bed cables, you will have to use a drill.. 
I've been planning to use openbuilds standoffs but they might heat up too much so the best option would be to use teflon ones.. something like
http://www.ebay.co.uk/itm/PTFE-Teflon-White-Tube-Pipe-2-to-3mm-wall-10-to-18mm-OD-6-to-12mm-ID/222625547740
Ideally, it should be 10mm dia. tube with 3-4mm hole, cut to 9-10mm ...

BOM:
- 3 x bed support pieces (ABS - 50% honeycomb infill)
- 3 x openbulids 9mm standoffs - this should be replaced with teflon ones..
- 3 x M3 15mm DIN 912 bolts with nuts
- 6 x M5 8mm button head bolts
- 3 x M3 6mm DIN 912 bolts with nuts - for RAMPS bracket

Enjoy!